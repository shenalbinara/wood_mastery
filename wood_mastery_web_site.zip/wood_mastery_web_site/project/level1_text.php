<?php

require 'level1.php'; // Ensure this path is correct relative to removedTest.php

use PHPUnit\Framework\TestCase;

class level1Test extends TestCase
{
    public function testlevel1Function() {
        // Pass an argument to removedFunction
        $result = level1Function('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = level1Function('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>














